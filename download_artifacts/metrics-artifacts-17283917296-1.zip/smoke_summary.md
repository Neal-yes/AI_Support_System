## Smoke: /api/v1/ask

- Plain: rc=0 http=200
  - response_len=16
  - use_rag=false
- RAG: rc=0 http=200
  - sources_len= match=
