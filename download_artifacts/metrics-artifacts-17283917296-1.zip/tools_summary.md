## Tools Gateway Summary

- window: requests_1m=2 errors_1m=1.3333333333333333 error_ratio_1m=0.02129666666666667
- rate_limited_1m=0 retries_1m=2.6666666666666665 cache_hits_1m=0
- circuit_open_5m=0
- gates: error_ratio_1m_max=0.25 rate_limit_incr_1m_max=10 circuit_open_incr_5m_max=5
- result: PASS
