## Smoke: /api/v1/ask

- Plain: rc=0 http=200
  - response_len=14
  - use_rag=
- RAG: rc=0 http=200
  - sources_len=5 match=true
