## RAG Gate Summary
- collection: metrics_demo_1d
- total: 50
- hit_ratio: 1.0
- avg_top1: 0.8716654111999997
- csv: artifacts/metrics/rag_eval.csv (in artifacts)

## Smoke Ask
- collection: metrics_demo_1d
- plain: rc=0 http=200
- rag: rc=0 http=200
