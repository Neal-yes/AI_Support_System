## RAG Eval Gate

- total=50 hit_ratio=1.0 avg_top1=0.8716654111999997 top_k=5
- thresholds: hit_ratio>=0.60 both avg_top1>=0.35 (min_total=10 require_min_total=0)

- csv: rag_eval.csv

collection,total,hit_ratio,avg_top1,avg_mean_score,top_k
metrics_demo_1d,50,1.000000,0.871665,0.793092,5
## Collection and Key Results
- Collection: metrics_demo_1d
- Hit Ratio: 1.0
- Average Top1 Score: 0.8716654111999997
